# HireSwipe

PHP + MySQL job-matching app. This package contains the UI screens for
sign up, sign in, OTP verification, forgot password, and onboarding
(employee and employer), plus the database schema.

## File structure

```
hireswipe/
├── index.php                      Entry point (redirects by session state)
├── config/
│   └── db.php                     PDO connection (uses env vars, see below)
├── includes/
│   ├── head.php                   Shared <head> + <body> opening tag
│   └── footer.php                 Shared </body></html> + JS include
├── assets/
│   ├── css/style.css              All shared styles (colors, buttons, forms, chips)
│   ├── js/app.js                  OTP auto-advance, chip selection, password match check
│   └── images/                    (empty — put logos/icons here)
├── auth/
│   ├── signup.php                 Name, email, mobile, password, confirm password
│   ├── signin.php                 Email+password, with a link to mobile OTP
│   ├── verify-otp.php             6-digit OTP, reused for login/signup/reset (?purpose=)
│   ├── forgot-password.php        Request a reset code by email or mobile
│   └── reset-password.php         New password + confirm password, after OTP
├── onboarding/
│   ├── choose-role.php            Employee vs employer
│   ├── employee-setup.php         employee_profiles + employee_industries fields
│   └── employer-setup.php         employer_profiles + first jobs row fields
└── database/
    └── hireswipe_schema.sql       Full MySQL schema
```

## What's wired up vs. what's a placeholder

- Every form's `action` points at a `*-submit.php` endpoint (e.g.
  `auth/signup-submit.php`) that isn't included here — that's where
  you'll hash the password, insert into `users`, hit
  `otp_codes`/`password_resets`, etc. using `config/db.php`.
- `employee-setup.php` and `employer-setup.php` hardcode the
  employment-type and industry chip options as PHP arrays — swap
  those loops for a `SELECT` against `employment_types` / `industries`.
- File inputs (picture, CV, logo) submit as real `multipart/form-data`
  fields (`picture`, `cv`, `logo`); handle the upload server-side and
  store the resulting path in `picture_path` / `cv_path` / `logo_path`.
- `assets/js/app.js` writes chip selections into a hidden input
  (`employment_type`, `industries`) so they post with the form as
  plain values — no framework required.

## Getting it running

1. Create the database: `mysql -u root -p < database/hireswipe_schema.sql`
2. Set `HIRESWIPE_DB_HOST` / `_DB_NAME` / `_DB_USER` / `_DB_PASS` env vars, or edit the defaults in `config/db.php`.
3. Point your webserver's document root at this folder (Apache/Nginx/`php -S localhost:8000`).
4. Visit `/auth/signup.php` to start the flow.
