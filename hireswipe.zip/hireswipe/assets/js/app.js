// HireSwipe — small UI behaviors shared across pages

document.addEventListener("DOMContentLoaded", () => {
  // OTP boxes: auto-advance to the next box, backspace goes back
  document.querySelectorAll(".otp-row").forEach((row) => {
    const boxes = Array.from(row.querySelectorAll("input"));
    boxes.forEach((box, i) => {
      box.addEventListener("input", () => {
        box.value = box.value.replace(/[^0-9]/g, "").slice(0, 1);
        if (box.value && boxes[i + 1]) boxes[i + 1].focus();
      });
      box.addEventListener("keydown", (e) => {
        if (e.key === "Backspace" && !box.value && boxes[i - 1]) {
          boxes[i - 1].focus();
        }
      });
    });
  });

  // Chip groups: single-select (employment type) vs multi-select (industries).
  // The hidden input right after each group holds the value(s) that get submitted.
  document.querySelectorAll(".chip-group").forEach((group) => {
    const multi = group.dataset.multi === "true";
    const hiddenInput = group.nextElementSibling && group.nextElementSibling.matches('input[type="hidden"]')
      ? group.nextElementSibling
      : null;

    const syncHiddenInput = () => {
      if (!hiddenInput) return;
      const active = Array.from(group.querySelectorAll(".chip.active")).map((c) => c.dataset.value);
      hiddenInput.value = multi ? active.join(",") : (active[0] || "");
    };

    group.querySelectorAll(".chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        if (!multi) {
          group.querySelectorAll(".chip").forEach((c) => c.classList.remove("active"));
        }
        chip.classList.toggle("active");
        syncHiddenInput();
      });
    });

    syncHiddenInput();
  });

  // New password / confirm password match check
  document.querySelectorAll("form[data-confirm-password]").forEach((form) => {
    const pass = form.querySelector('[name="password"]');
    const confirm = form.querySelector('[name="password_confirm"]');
    if (!pass || !confirm) return;
    const check = () => {
      const errorEl = confirm.parentElement.querySelector(".error");
      if (confirm.value && confirm.value !== pass.value) {
        if (errorEl) errorEl.textContent = "Passwords do not match.";
      } else if (errorEl) {
        errorEl.textContent = "";
      }
    };
    pass.addEventListener("input", check);
    confirm.addEventListener("input", check);
  });
});
