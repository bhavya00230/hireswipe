<?php
/**
 * auth/forgot-password-submit.php
 * Handles POST from auth/forgot-password.php.
 * Looks the user up by email OR mobile, then sends a reset_password OTP
 * to their mobile number on file.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

function backToForgotPassword(string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /auth/forgot-password.php');
    exit;
}

$identifier = trim($_POST['identifier'] ?? '');

if ($identifier === '') {
    backToForgotPassword('Enter your email or mobile number.');
}

$stmt = $pdo->prepare('SELECT id, mobile FROM users WHERE (email = :id OR mobile = :id) AND status = "active" LIMIT 1');
$stmt->execute(['id' => $identifier]);
$user = $stmt->fetch();

if (!$user) {
    backToForgotPassword('No account found with that email or mobile number.');
}

$otp = createOtp($pdo, (int) $user['id'], $user['mobile'], 'reset_password');

$_SESSION['pending_user_id'] = (int) $user['id'];
$_SESSION['pending_mobile']  = $user['mobile'];
$_SESSION['dev_otp']         = $otp; // remove once real SMS sending is wired up

header('Location: /auth/verify-otp.php?purpose=reset_password');
exit;
