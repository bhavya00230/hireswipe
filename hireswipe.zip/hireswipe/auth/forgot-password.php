<?php
$pageTitle = 'Reset password';
include __DIR__ . '/../includes/head.php';
?>
<div class="screen">
  <div class="topbar">
    <a href="/auth/signin.php" class="back" aria-label="Back to sign in">‹</a>
    <div class="step-label">Reset password</div>
    <div style="width:22px"></div>
  </div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <h1 class="title">Forgot your password?</h1>
      <p class="subtitle">Enter your email or mobile number and we'll send you a code to reset it.</p>
    </div>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/auth/forgot-password-submit.php" class="stack">
      <div class="field">
        <label for="identifier">Email or mobile number</label>
        <input id="identifier" name="identifier" type="text" placeholder="jordan@email.com" required>
      </div>
      <button type="submit" class="btn btn-outline">Send reset code</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
