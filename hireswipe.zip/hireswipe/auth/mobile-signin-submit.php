<?php
/**
 * auth/mobile-signin-submit.php
 * Handles POST from auth/mobile-signin.php.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$mobile = trim($_POST['mobile'] ?? '');

if ($mobile === '') {
    $_SESSION['flash_error'] = 'Enter your mobile number.';
    header('Location: /auth/mobile-signin.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id FROM users WHERE mobile = :mobile AND status = "active" LIMIT 1');
$stmt->execute(['mobile' => $mobile]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['flash_error'] = 'No account found with that mobile number.';
    header('Location: /auth/mobile-signin.php');
    exit;
}

$otp = createOtp($pdo, (int) $user['id'], $mobile, 'login');

$_SESSION['pending_user_id'] = (int) $user['id'];
$_SESSION['pending_mobile']  = $mobile;
$_SESSION['dev_otp']         = $otp; // remove once real SMS sending is wired up

header('Location: /auth/verify-otp.php?purpose=login');
exit;
