<?php
$pageTitle = 'Sign in with mobile';
include __DIR__ . '/../includes/head.php';
?>
<div class="screen">
  <div class="topbar">
    <a href="/auth/signin.php" class="back" aria-label="Back to sign in">‹</a>
    <div class="step-label">Mobile sign-in</div>
    <div style="width:22px"></div>
  </div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <h1 class="title">Sign in with your mobile number</h1>
      <p class="subtitle">We'll text you a 6-digit code.</p>
    </div>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/auth/mobile-signin-submit.php" class="stack">
      <div class="field">
        <label for="mobile">Mobile number</label>
        <input id="mobile" name="mobile" type="tel" placeholder="+91 98765 43210" required>
      </div>
      <button type="submit" class="btn btn-primary">Send code</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
