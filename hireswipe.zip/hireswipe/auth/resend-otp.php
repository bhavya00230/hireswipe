<?php
/**
 * auth/resend-otp.php
 * GET endpoint behind the "Resend code" link on verify-otp.php.
 * Issues a fresh OTP for the same pending user + purpose and sends them back.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$purpose = $_GET['purpose'] ?? 'login';
$allowedPurposes = ['login', 'signup', 'reset_password'];
if (!in_array($purpose, $allowedPurposes, true)) {
    $purpose = 'login';
}

if (empty($_SESSION['pending_user_id']) || empty($_SESSION['pending_mobile'])) {
    $_SESSION['flash_error'] = 'Your session expired. Please start again.';
    header('Location: /auth/signin.php');
    exit;
}

$otp = createOtp($pdo, (int) $_SESSION['pending_user_id'], $_SESSION['pending_mobile'], $purpose);
$_SESSION['dev_otp'] = $otp; // remove once real SMS sending is wired up

header('Location: /auth/verify-otp.php?purpose=' . urlencode($purpose));
exit;
