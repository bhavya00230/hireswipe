<?php
/**
 * auth/reset-password-submit.php
 * Handles POST from auth/reset-password.php.
 * Only reachable after verify-otp-submit.php set reset_verified_user_id.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

function backToResetPassword(string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /auth/reset-password.php');
    exit;
}

if (empty($_SESSION['reset_verified_user_id'])) {
    header('Location: /auth/forgot-password.php');
    exit;
}

$userId   = (int) $_SESSION['reset_verified_user_id'];
$password = $_POST['password'] ?? '';
$confirm  = $_POST['password_confirm'] ?? '';

if (strlen($password) < 8) {
    backToResetPassword('Password must be at least 8 characters.');
}
if ($password !== $confirm) {
    backToResetPassword('Passwords do not match.');
}

$pdo->prepare('UPDATE users SET password_hash = :hash, failed_login_count = 0, locked_until = NULL WHERE id = :id')
    ->execute([
        'hash' => password_hash($password, PASSWORD_DEFAULT),
        'id'   => $userId,
    ]);

unset($_SESSION['reset_verified_user_id']);
$_SESSION['flash_success'] = 'Password reset. Sign in with your new password.';

header('Location: /auth/signin.php');
exit;
