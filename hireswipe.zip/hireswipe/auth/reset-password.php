<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

// Only reachable after verify-otp-submit.php confirms a reset_password code.
if (empty($_SESSION['reset_verified_user_id'])) {
    header('Location: /auth/forgot-password.php');
    exit;
}

$pageTitle = 'New password';
include __DIR__ . '/../includes/head.php';
?>
<div class="screen">
  <div class="topbar">
    <a href="/auth/signin.php" class="back" aria-label="Back to sign in">‹</a>
    <div class="step-label">Reset password</div>
    <div style="width:22px"></div>
  </div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <h1 class="title">Set a new password</h1>
      <p class="subtitle">Code verified. Choose a new password for your account.</p>
    </div>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/auth/reset-password-submit.php" data-confirm-password class="stack">
      <div class="field">
        <label for="password">New password</label>
        <input id="password" name="password" type="password" placeholder="••••••••" minlength="8" required>
      </div>
      <div class="field">
        <label for="password_confirm">Confirm password</label>
        <input id="password_confirm" name="password_confirm" type="password" placeholder="••••••••" minlength="8" required>
        <div class="error" role="alert"></div>
      </div>
      <button type="submit" class="btn btn-primary">Reset password</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
