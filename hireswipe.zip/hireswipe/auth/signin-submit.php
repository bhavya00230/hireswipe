<?php
/**
 * auth/signin-submit.php
 * Handles POST from auth/signin.php.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

function backToSignin(string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /auth/signin.php');
    exit;
}

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if ($email === '' || $password === '') {
    backToSignin('Enter your email and password.');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
$stmt->execute(['email' => $email]);
$user = $stmt->fetch();

// Same generic message whether the email exists or the password is wrong —
// don't reveal which one was incorrect.
$genericError = 'Incorrect email or password.';

if (!$user || $user['status'] !== 'active') {
    backToSignin($genericError);
}

if (!empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
    backToSignin('Too many attempts. Try again in a few minutes.');
}

if (!password_verify($password, $user['password_hash'])) {
    $failed = (int) $user['failed_login_count'] + 1;
    $lockUntil = $failed >= 5 ? date('Y-m-d H:i:s', time() + 15 * 60) : null;
    $pdo->prepare('UPDATE users SET failed_login_count = :f, locked_until = :l WHERE id = :id')
        ->execute(['f' => $failed, 'l' => $lockUntil, 'id' => $user['id']]);
    backToSignin($genericError);
}

$pdo->prepare('UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login_at = NOW() WHERE id = :id')
    ->execute(['id' => $user['id']]);

$_SESSION['user_id'] = (int) $user['id'];
header('Location: ' . postLoginRedirect($user));
exit;
