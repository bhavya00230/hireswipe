<?php
$pageTitle = 'Sign in';
include __DIR__ . '/../includes/head.php';
?>
<div class="screen">
  <div class="brand">HireSwipe</div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <h1 class="title">Welcome back</h1>
      <p class="subtitle">Sign in to continue.</p>
    </div>

    <?php if (!empty($_SESSION['flash_success'])): ?>
      <p role="status" style="margin:0;font-size:14px;color:var(--accent)"><?= htmlspecialchars($_SESSION['flash_success']) ?></p>
      <?php unset($_SESSION['flash_success']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/auth/signin-submit.php" class="stack">
      <div class="field">
        <label for="email">Email address</label>
        <input id="email" name="email" type="email" placeholder="jordan@email.com" required>
      </div>
      <div class="field">
        <div class="row-between">
          <label for="password" style="margin:0">Password</label>
          <a href="/auth/forgot-password.php" class="link-accent" style="font-size:13px">Forgot password?</a>
        </div>
        <input id="password" name="password" type="password" placeholder="••••••••" required>
      </div>

      <button type="submit" class="btn btn-primary">Sign in</button>
    </form>

    <div class="divider">
      <div class="line"></div><span>or</span><div class="line"></div>
    </div>

    <a href="/auth/mobile-signin.php" class="btn btn-outline">Sign in with mobile OTP</a>

    <p style="margin:0;text-align:center;font-size:14px;color:var(--muted)">
      New to HireSwipe? <a href="/auth/signup.php" class="link-accent">Create account</a>
    </p>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
