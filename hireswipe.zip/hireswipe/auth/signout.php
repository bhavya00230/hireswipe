<?php
/**
 * auth/signout.php
 * Destroys the session and sends the user back to sign in.
 */
require_once __DIR__ . '/../includes/session.php';

$_SESSION = [];
session_destroy();

header('Location: /auth/signin.php');
exit;
