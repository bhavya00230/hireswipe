<?php
/**
 * auth/signup-submit.php
 * Handles POST from auth/signup.php.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

function backToSignup(string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /auth/signup.php');
    exit;
}

$name     = trim($_POST['name'] ?? '');
$email    = trim($_POST['email'] ?? '');
$mobile   = trim($_POST['mobile'] ?? '');
$password = $_POST['password'] ?? '';
$confirm  = $_POST['password_confirm'] ?? '';

if ($name === '' || $email === '' || $mobile === '' || $password === '') {
    backToSignup('Please fill in every field.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    backToSignup('That email address doesn\'t look right.');
}
if (strlen($password) < 8) {
    backToSignup('Password must be at least 8 characters.');
}
if ($password !== $confirm) {
    backToSignup('Passwords do not match.');
}

// Uniqueness check
$check = $pdo->prepare('SELECT id FROM users WHERE email = :email OR mobile = :mobile LIMIT 1');
$check->execute(['email' => $email, 'mobile' => $mobile]);
if ($check->fetch()) {
    backToSignup('An account with that email or mobile number already exists.');
}

$insert = $pdo->prepare(
    'INSERT INTO users (name, email, mobile, password_hash, onboarding_status)
     VALUES (:name, :email, :mobile, :password_hash, :status)'
);
$insert->execute([
    'name'          => $name,
    'email'         => $email,
    'mobile'        => $mobile,
    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
    'status'        => 'role_pending',
]);
$userId = (int) $pdo->lastInsertId();

$otp = createOtp($pdo, $userId, $mobile, 'signup');

$_SESSION['pending_user_id'] = $userId;
$_SESSION['pending_mobile']  = $mobile;
// No SMS gateway wired up yet — show the code so you can test the flow locally.
// Remove this line once real SMS sending is in place.
$_SESSION['dev_otp'] = $otp;

header('Location: /auth/verify-otp.php?purpose=signup');
exit;
