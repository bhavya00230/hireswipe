<?php
$pageTitle = 'Sign up';
include __DIR__ . '/../includes/head.php';
?>
<div class="screen">
  <div class="brand">HireSwipe</div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <h1 class="title">Create your account</h1>
      <p class="subtitle">Find your next job, or your next hire.</p>
    </div>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p class="field-error" role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/auth/signup-submit.php" data-confirm-password class="stack">
      <div class="field">
        <label for="name">Full name</label>
        <input id="name" name="name" type="text" placeholder="Jordan Lee" required>
      </div>
      <div class="field">
        <label for="email">Email address</label>
        <input id="email" name="email" type="email" placeholder="jordan@email.com" required>
      </div>
      <div class="field">
        <label for="mobile">Mobile number</label>
        <input id="mobile" name="mobile" type="tel" placeholder="+91 98765 43210" required>
      </div>
      <div class="field">
        <label for="password">New password</label>
        <input id="password" name="password" type="password" placeholder="••••••••" minlength="8" required>
      </div>
      <div class="field">
        <label for="password_confirm">Confirm password</label>
        <input id="password_confirm" name="password_confirm" type="password" placeholder="••••••••" minlength="8" required>
        <div class="error" role="alert"></div>
      </div>

      <button type="submit" class="btn btn-primary">Create account</button>
    </form>

    <p style="margin:0;text-align:center;font-size:14px;color:var(--muted)">
      Already have an account? <a href="/auth/signin.php" class="link-accent">Sign in</a>
    </p>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
