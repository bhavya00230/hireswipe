<?php
/**
 * auth/verify-otp-submit.php
 * Handles POST from auth/verify-otp.php for all three purposes:
 * signup, login (mobile OTP), and reset_password.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$purpose = $_POST['purpose'] ?? 'login';
$allowedPurposes = ['login', 'signup', 'reset_password'];
if (!in_array($purpose, $allowedPurposes, true)) {
    $purpose = 'login';
}

function backToVerify(string $purpose, string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /auth/verify-otp.php?purpose=' . urlencode($purpose));
    exit;
}

$digits = $_POST['otp'] ?? [];
$otp = is_array($digits) ? implode('', $digits) : (string) $digits;

if (empty($_SESSION['pending_user_id'])) {
    backToVerify($purpose, 'Your session expired. Please start again.');
}
if (!preg_match('/^\d{6}$/', $otp)) {
    backToVerify($purpose, 'Enter the full 6-digit code.');
}

$userId = (int) $_SESSION['pending_user_id'];

if (!verifyOtp($pdo, $userId, $purpose, $otp)) {
    backToVerify($purpose, 'That code is incorrect or has expired.');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    backToVerify($purpose, 'That account no longer exists.');
}

// Clear the one-time state now that the code has been consumed.
unset($_SESSION['pending_mobile'], $_SESSION['dev_otp']);

if ($purpose === 'reset_password') {
    // Don't log the user in yet — just prove they own the account, then
    // let reset-password-submit.php set the new password.
    unset($_SESSION['pending_user_id']);
    $_SESSION['reset_verified_user_id'] = $userId;
    header('Location: /auth/reset-password.php');
    exit;
}

// signup or login: this verification logs the user in.
unset($_SESSION['pending_user_id']);
$_SESSION['user_id'] = $userId;

$pdo->prepare('UPDATE users SET is_mobile_verified = 1, failed_login_count = 0, locked_until = NULL, last_login_at = NOW() WHERE id = :id')
    ->execute(['id' => $userId]);

header('Location: ' . postLoginRedirect($user));
exit;
