<?php
$pageTitle = 'Verify code';
include __DIR__ . '/../includes/head.php';

// purpose = login | signup | reset_password — matches otp_codes.purpose
$purpose = $_GET['purpose'] ?? 'login';
$nextPage = $purpose === 'reset_password' ? '/auth/reset-password.php' : '/onboarding/choose-role.php';
?>
<div class="screen">
  <div class="topbar">
    <a href="/auth/signin.php" class="back" aria-label="Back to sign in">‹</a>
    <div class="step-label">Verify</div>
    <div style="width:22px"></div>
  </div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <h1 class="title">Enter verification code</h1>
      <p class="subtitle">We sent a 6-digit code to your mobile number.</p>
    </div>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['dev_otp'])): ?>
      <!-- No SMS gateway is wired up yet, so the code is shown here for local testing.
           Remove this block once real SMS sending is in place. -->
      <p role="status" style="margin:0;font-size:13px;color:var(--muted)">Dev mode — your code is <strong style="color:var(--text)"><?= htmlspecialchars($_SESSION['dev_otp']) ?></strong></p>
    <?php endif; ?>

    <form method="post" action="/auth/verify-otp-submit.php" class="stack">
      <input type="hidden" name="purpose" value="<?= htmlspecialchars($purpose) ?>">
      <fieldset style="border:0;padding:0;margin:0">
        <legend style="font-size:13px;font-weight:600;margin-bottom:8px">Verification code</legend>
        <div class="otp-row">
          <input aria-label="Digit 1" name="otp[]" type="text" inputmode="numeric" maxlength="1" required>
          <input aria-label="Digit 2" name="otp[]" type="text" inputmode="numeric" maxlength="1" required>
          <input aria-label="Digit 3" name="otp[]" type="text" inputmode="numeric" maxlength="1" required>
          <input aria-label="Digit 4" name="otp[]" type="text" inputmode="numeric" maxlength="1" required>
          <input aria-label="Digit 5" name="otp[]" type="text" inputmode="numeric" maxlength="1" required>
          <input aria-label="Digit 6" name="otp[]" type="text" inputmode="numeric" maxlength="1" required>
        </div>
      </fieldset>

      <p style="margin:0;text-align:center;font-size:14px;color:var(--muted)">
        Didn't get a code? <a href="/auth/resend-otp.php?purpose=<?= urlencode($purpose) ?>" class="link-accent">Resend code</a>
      </p>

      <button type="submit" class="btn btn-primary">Verify &amp; continue</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
