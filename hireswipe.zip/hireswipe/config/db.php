<?php
/**
 * config/db.php
 * PDO connection to the hireswipe MySQL database.
 * Fill in real credentials via environment variables in production —
 * never commit real credentials to source control.
 */

$DB_HOST = getenv('HIRESWIPE_DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('HIRESWIPE_DB_NAME') ?: 'hireswipe';
$DB_USER = getenv('HIRESWIPE_DB_USER') ?: 'root';
$DB_PASS = getenv('HIRESWIPE_DB_PASS') ?: '';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // Never leak DB details to the browser in production.
    http_response_code(500);
    exit('Database connection failed.');
}
