<?php
/**
 * dashboard.php
 * Placeholder landing page after sign-in / onboarding — replace with the
 * real employee or employer home screen.
 */
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';

$userId = requireLogin();

$stmt = $pdo->prepare('SELECT name, role, onboarding_status FROM users WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: /auth/signin.php');
    exit;
}
if (empty($user['role'])) {
    header('Location: /onboarding/choose-role.php');
    exit;
}

$pageTitle = 'Dashboard';
include __DIR__ . '/includes/head.php';
?>
<div class="screen">
  <div class="brand">HireSwipe</div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <div class="eyebrow">Signed in as <?= htmlspecialchars($user['role']) ?></div>
      <h1 class="title">Welcome, <?= htmlspecialchars($user['name']) ?></h1>
      <p class="subtitle">Onboarding is complete. This is a stand-in home screen — build the real <?= htmlspecialchars($user['role']) ?> experience here.</p>
    </div>
    <a href="/auth/signout.php" class="btn btn-outline">Sign out</a>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
