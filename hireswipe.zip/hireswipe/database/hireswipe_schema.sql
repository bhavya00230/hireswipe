-- =====================================================
-- HireSwipe database schema (MySQL 8 / MariaDB, InnoDB)
-- Flow: signup -> signin (email/password or mobile OTP)
--       -> forgot password -> onboarding (employee | employer)
-- =====================================================

CREATE DATABASE IF NOT EXISTS hireswipe
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hireswipe;

-- -----------------------------------------------------
-- 1. USERS  (one row per account, both roles)
-- "New password + confirm password" is validated in PHP;
-- only the hash is stored (password_hash() / bcrypt).
-- -----------------------------------------------------
CREATE TABLE users (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name               VARCHAR(120) NOT NULL,
  email              VARCHAR(190) NOT NULL,
  mobile             VARCHAR(20)  NOT NULL,          -- E.164, e.g. +919876543210
  password_hash      VARCHAR(255) NOT NULL,
  role               ENUM('employee','employer') NULL, -- NULL until onboarding step 1
  is_email_verified  TINYINT(1) NOT NULL DEFAULT 0,
  is_mobile_verified TINYINT(1) NOT NULL DEFAULT 0,
  onboarding_status  ENUM('role_pending','profile_pending','completed')
                     NOT NULL DEFAULT 'role_pending',
  status             ENUM('active','blocked','deleted') NOT NULL DEFAULT 'active',
  failed_login_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until       DATETIME NULL,
  last_login_at      DATETIME NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                     ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email  (email),
  UNIQUE KEY uq_users_mobile (mobile),
  KEY idx_users_role (role)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- 2. OTP CODES  (mobile login OTP, signup verification)
-- Store a hash of the OTP, never the plain code.
-- -----------------------------------------------------
CREATE TABLE otp_codes (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id       BIGINT UNSIGNED NULL,               -- NULL if number not registered yet
  mobile        VARCHAR(20) NOT NULL,
  otp_hash      VARCHAR(255) NOT NULL,
  purpose       ENUM('login','signup','reset_password') NOT NULL,
  attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0, -- wrong tries
  expires_at    DATETIME NOT NULL,                   -- e.g. now + 5 min
  used_at       DATETIME NULL,
  ip_address    VARCHAR(45) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_otp_mobile (mobile, purpose, expires_at),
  CONSTRAINT fk_otp_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- 3. PASSWORD RESETS  (forgot password via email link)
-- Store SHA-256 of the token; email the raw token.
-- (For mobile reset, use otp_codes with purpose='reset_password'.)
-- -----------------------------------------------------
CREATE TABLE password_resets (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT UNSIGNED NOT NULL,
  token_hash  CHAR(64) NOT NULL,
  expires_at  DATETIME NOT NULL,                      -- e.g. now + 30 min
  used_at     DATETIME NULL,
  ip_address  VARCHAR(45) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reset_token (token_hash),
  KEY idx_reset_user (user_id),
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- 4. AUTH SESSIONS / REFRESH TOKENS  (optional but recommended
--    for mobile app / API login)
-- -----------------------------------------------------
CREATE TABLE user_sessions (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id       BIGINT UNSIGNED NOT NULL,
  token_hash    CHAR(64) NOT NULL,
  device_info   VARCHAR(255) NULL,
  ip_address    VARCHAR(45) NULL,
  expires_at    DATETIME NOT NULL,
  revoked_at    DATETIME NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_session_token (token_hash),
  KEY idx_session_user (user_id),
  CONSTRAINT fk_session_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- 5. LOOKUP TABLES  (shared dropdown data)
-- -----------------------------------------------------
CREATE TABLE industries (
  id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name  VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE employment_types (          -- Full-time, Part-time, Contract, Internship...
  id    TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name  VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO employment_types (name) VALUES
  ('Full-time'),('Part-time'),('Contract'),('Freelance'),('Internship'),('Remote');

-- -----------------------------------------------------
-- 6. EMPLOYEE (JOB SEEKER) PROFILE
-- name/email/mobile already live in users; not duplicated.
-- Fields match the job-seeker setup form exactly:
-- age, location, nationality, qualification, experience,
-- expected salary, employment type, industries, picture, CV.
-- -----------------------------------------------------
CREATE TABLE employee_profiles (
  id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id              BIGINT UNSIGNED NOT NULL,
  age                  TINYINT UNSIGNED NULL,
  location             VARCHAR(150) NULL,           -- free-text city/area as entered on the form
  nationality          VARCHAR(80)  NULL,
  qualification        VARCHAR(120) NULL,
  experience           DECIMAL(4,1) NOT NULL DEFAULT 0.0,  -- years of experience
  expected_salary      DECIMAL(12,2) NULL,
  employment_type_id   TINYINT UNSIGNED NULL,
  picture_path         VARCHAR(255) NULL,           -- store file path/URL, not the blob
  cv_path              VARCHAR(255) NULL,
  created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                       ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_emp_user (user_id),
  KEY idx_emp_location (location),
  CONSTRAINT fk_emp_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_emp_type FOREIGN KEY (employment_type_id)
    REFERENCES employment_types(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Employee can pick multiple industries (many-to-many)
CREATE TABLE employee_industries (
  employee_profile_id BIGINT UNSIGNED NOT NULL,
  industry_id         INT UNSIGNED NOT NULL,
  PRIMARY KEY (employee_profile_id, industry_id),
  CONSTRAINT fk_ei_profile  FOREIGN KEY (employee_profile_id)
    REFERENCES employee_profiles(id) ON DELETE CASCADE,
  CONSTRAINT fk_ei_industry FOREIGN KEY (industry_id)
    REFERENCES industries(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- 7. EMPLOYER / COMPANY PROFILE  (setup step)
-- Fields: company, location, industry, logo.
-- -----------------------------------------------------
CREATE TABLE employer_profiles (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id        BIGINT UNSIGNED NOT NULL,
  company_name   VARCHAR(190) NOT NULL,
  location       VARCHAR(150) NULL,             -- free-text location as entered on the form
  industry_id    INT UNSIGNED NULL,
  logo_path      VARCHAR(255) NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                 ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_employer_user (user_id),
  KEY idx_employer_location (location),
  CONSTRAINT fk_employer_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_employer_industry FOREIGN KEY (industry_id)
    REFERENCES industries(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- 8. JOBS  (position, employment type, salary, job detail)
-- One employer can post many jobs; the onboarding form
-- creates the first row here.
-- -----------------------------------------------------
CREATE TABLE jobs (
  id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employer_id         BIGINT UNSIGNED NOT NULL,       -- employer_profiles.id
  position            VARCHAR(150) NOT NULL,          -- job title
  employment_type_id  TINYINT UNSIGNED NULL,
  salary              DECIMAL(12,2) NULL,
  job_details         TEXT NOT NULL,                  -- description / requirements
  created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                      ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_jobs_employer (employer_id),
  KEY idx_jobs_type (employment_type_id),
  CONSTRAINT fk_jobs_employer FOREIGN KEY (employer_id)
    REFERENCES employer_profiles(id) ON DELETE CASCADE,
  CONSTRAINT fk_jobs_type FOREIGN KEY (employment_type_id)
    REFERENCES employment_types(id) ON DELETE SET NULL
) ENGINE=InnoDB;
