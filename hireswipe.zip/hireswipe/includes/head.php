<?php
/**
 * includes/head.php
 * Include at the top of every page: <?php $pageTitle = 'Sign up'; include __DIR__ . '/../includes/head.php'; ?>
 */
require_once __DIR__ . '/session.php';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' – HireSwipe' : 'HireSwipe' ?></title>
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
