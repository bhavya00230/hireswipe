<?php
/**
 * includes/helpers.php
 * Small helpers shared by the *-submit.php handlers.
 * Requires config/db.php ($pdo) and includes/session.php to already be loaded.
 */

/** Generate a 6-digit numeric OTP as a string, e.g. "042917". */
function generateOtp(): string
{
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

/** Never store the plain OTP — only its hash. */
function hashOtp(string $otp): string
{
    return hash('sha256', $otp);
}

/**
 * Insert a fresh OTP row for a user and return the PLAIN otp (to "send" it —
 * here we just hand it back to the caller / dev banner, no real SMS gateway).
 */
function createOtp(PDO $pdo, ?int $userId, string $mobile, string $purpose, int $ttlMinutes = 5): string
{
    $otp = generateOtp();
    $stmt = $pdo->prepare(
        'INSERT INTO otp_codes (user_id, mobile, otp_hash, purpose, expires_at)
         VALUES (:user_id, :mobile, :otp_hash, :purpose, DATE_ADD(NOW(), INTERVAL :ttl MINUTE))'
    );
    $stmt->execute([
        'user_id'  => $userId,
        'mobile'   => $mobile,
        'otp_hash' => hashOtp($otp),
        'purpose'  => $purpose,
        'ttl'      => $ttlMinutes,
    ]);
    return $otp;
}

/**
 * Check a submitted OTP against the most recent unused, unexpired row for
 * this user + purpose. Marks it used on success; counts the attempt either way.
 * Returns true/false.
 */
function verifyOtp(PDO $pdo, int $userId, string $purpose, string $submittedOtp): bool
{
    $stmt = $pdo->prepare(
        'SELECT id, otp_hash, attempts FROM otp_codes
         WHERE user_id = :user_id AND purpose = :purpose
           AND used_at IS NULL AND expires_at > NOW()
         ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute(['user_id' => $userId, 'purpose' => $purpose]);
    $row = $stmt->fetch();

    if (!$row || $row['attempts'] >= 5) {
        return false;
    }

    $ok = hash_equals($row['otp_hash'], hashOtp($submittedOtp));

    if ($ok) {
        $pdo->prepare('UPDATE otp_codes SET used_at = NOW() WHERE id = :id')
            ->execute(['id' => $row['id']]);
    } else {
        $pdo->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = :id')
            ->execute(['id' => $row['id']]);
    }

    return $ok;
}

/**
 * Look up a row by name in a simple lookup table (industries, employment_types),
 * inserting it if it doesn't exist yet. Returns its id.
 */
function getOrCreateLookupId(PDO $pdo, string $table, string $name): int
{
    $name = trim($name);
    $select = $pdo->prepare("SELECT id FROM `$table` WHERE name = :name LIMIT 1");
    $select->execute(['name' => $name]);
    $id = $select->fetchColumn();
    if ($id) {
        return (int) $id;
    }
    $insert = $pdo->prepare("INSERT INTO `$table` (name) VALUES (:name)");
    $insert->execute(['name' => $name]);
    return (int) $pdo->lastInsertId();
}

/**
 * Move an uploaded file into /uploads/<subdir>/ with a random name and
 * return its web-relative path, or null if no file was submitted.
 * $subdir is one of 'pictures' | 'cv' | 'logos'.
 */
function handleUpload(array $file, string $subdir): ?string
{
    if (empty($file['name']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload failed with error code ' . $file['error']);
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['pictures' => ['jpg', 'jpeg', 'png', 'webp'], 'cv' => ['pdf'], 'logos' => ['jpg', 'jpeg', 'png', 'webp']];
    if (!in_array($ext, $allowed[$subdir] ?? [], true)) {
        throw new RuntimeException('Unsupported file type: .' . $ext);
    }

    $dir = __DIR__ . '/../uploads/' . $subdir;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $filename = bin2hex(random_bytes(8)) . '.' . $ext;
    move_uploaded_file($file['tmp_name'], $dir . '/' . $filename);

    return '/uploads/' . $subdir . '/' . $filename;
}

/** Redirect to sign in if no one is logged in; otherwise return the user id. */
function requireLogin(): int
{
    if (empty($_SESSION['user_id'])) {
        header('Location: /auth/signin.php');
        exit;
    }
    return (int) $_SESSION['user_id'];
}

/** Show only the last 4 digits of a mobile number, e.g. "+91 •••••• 3210". */
function maskMobile(string $mobile): string
{
    $last4 = substr(preg_replace('/\D/', '', $mobile), -4);
    return '•••••• ' . $last4;
}

/** Where to send a user after signing in / verifying, based on onboarding state. */
function postLoginRedirect(array $user): string
{
    if (empty($user['role'])) {
        return '/onboarding/choose-role.php';
    }
    if ($user['onboarding_status'] !== 'completed') {
        return $user['role'] === 'employer'
            ? '/onboarding/employer-setup.php'
            : '/onboarding/employee-setup.php';
    }
    return '/dashboard.php';
}
