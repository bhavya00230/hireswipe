<?php
/**
 * includes/session.php
 * Starts the session once, however many files require it in one request.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
