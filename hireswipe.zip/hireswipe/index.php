<?php
/**
 * index.php — app entry point.
 * Replace this with real session logic:
 * - no session → /auth/signin.php
 * - logged in but users.onboarding_status != 'completed' → /onboarding/choose-role.php
 * - logged in and onboarding complete → your app's home screen
 */
header('Location: /auth/signup.php');
exit;
