<?php
$pageTitle = 'Choose role';
include __DIR__ . '/../includes/head.php';
?>
<div class="screen">
  <div class="brand">HireSwipe</div>
  <div class="content">
    <div class="stack" style="gap:6px">
      <div class="eyebrow">Onboarding</div>
      <h1 class="title">How do you want to use HireSwipe?</h1>
      <p class="subtitle">You can switch later from settings.</p>
    </div>

    <div class="stack">
      <a href="/onboarding/employee-setup.php" class="role-card">
        <div class="role-title">I'm looking for a job</div>
        <div class="role-desc">Build a profile and get matched with roles that fit.</div>
        <div class="role-cta">Continue as job seeker ›</div>
      </a>
      <a href="/onboarding/employer-setup.php" class="role-card">
        <div class="role-title">I'm hiring</div>
        <div class="role-desc">Set up your company and post your first role.</div>
        <div class="role-cta">Continue as employer ›</div>
      </a>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
