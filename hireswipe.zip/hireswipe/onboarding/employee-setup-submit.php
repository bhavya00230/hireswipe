<?php
/**
 * onboarding/employee-setup-submit.php
 * Handles POST from onboarding/employee-setup.php.
 * Upserts employee_profiles, syncs employee_industries, and marks
 * onboarding complete with role = employee.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$userId = requireLogin();

function backToEmployeeSetup(string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /onboarding/employee-setup.php');
    exit;
}

$age             = trim($_POST['age'] ?? '');
$location        = trim($_POST['location'] ?? '');
$nationality     = trim($_POST['nationality'] ?? '');
$qualification   = trim($_POST['qualification'] ?? '');
$experience      = trim($_POST['experience'] ?? '0');
$expectedSalary  = trim($_POST['expected_salary'] ?? '');
$employmentType  = trim($_POST['employment_type'] ?? '');
$industriesInput = trim($_POST['industries'] ?? '');

if ($age === '' || $location === '') {
    backToEmployeeSetup('Age and location are required.');
}

try {
    $picturePath = handleUpload($_FILES['picture'] ?? [], 'pictures');
    $cvPath      = handleUpload($_FILES['cv'] ?? [], 'cv');
} catch (RuntimeException $e) {
    backToEmployeeSetup($e->getMessage());
}

$employmentTypeId = $employmentType !== ''
    ? getOrCreateLookupId($pdo, 'employment_types', $employmentType)
    : null;

$pdo->beginTransaction();
try {
    // Upsert: one profile row per user (employee_profiles.user_id is UNIQUE).
    $stmt = $pdo->prepare(
        'INSERT INTO employee_profiles
            (user_id, age, location, nationality, qualification, experience, expected_salary, employment_type_id, picture_path, cv_path)
         VALUES
            (:user_id, :age, :location, :nationality, :qualification, :experience, :expected_salary, :employment_type_id, :picture_path, :cv_path)
         ON DUPLICATE KEY UPDATE
            age = VALUES(age),
            location = VALUES(location),
            nationality = VALUES(nationality),
            qualification = VALUES(qualification),
            experience = VALUES(experience),
            expected_salary = VALUES(expected_salary),
            employment_type_id = VALUES(employment_type_id),
            picture_path = COALESCE(VALUES(picture_path), picture_path),
            cv_path = COALESCE(VALUES(cv_path), cv_path)'
    );
    $stmt->execute([
        'user_id'             => $userId,
        'age'                 => $age,
        'location'            => $location,
        'nationality'         => $nationality !== '' ? $nationality : null,
        'qualification'       => $qualification !== '' ? $qualification : null,
        'experience'          => $experience !== '' ? $experience : 0,
        'expected_salary'     => $expectedSalary !== '' ? $expectedSalary : null,
        'employment_type_id'  => $employmentTypeId,
        'picture_path'        => $picturePath,
        'cv_path'             => $cvPath,
    ]);

    $profileId = (int) $pdo->query('SELECT id FROM employee_profiles WHERE user_id = ' . (int) $userId)->fetchColumn();

    // Sync industries: clear and re-insert from the submitted comma-separated list.
    $pdo->prepare('DELETE FROM employee_industries WHERE employee_profile_id = :id')
        ->execute(['id' => $profileId]);

    if ($industriesInput !== '') {
        $names = array_filter(array_map('trim', explode(',', $industriesInput)));
        $insertIndustry = $pdo->prepare(
            'INSERT IGNORE INTO employee_industries (employee_profile_id, industry_id) VALUES (:profile_id, :industry_id)'
        );
        foreach ($names as $name) {
            $industryId = getOrCreateLookupId($pdo, 'industries', $name);
            $insertIndustry->execute(['profile_id' => $profileId, 'industry_id' => $industryId]);
        }
    }

    $pdo->prepare("UPDATE users SET role = 'employee', onboarding_status = 'completed' WHERE id = :id")
        ->execute(['id' => $userId]);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    backToEmployeeSetup('Something went wrong saving your profile. Please try again.');
}

header('Location: /dashboard.php');
exit;
