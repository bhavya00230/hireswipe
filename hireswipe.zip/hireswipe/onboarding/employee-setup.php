<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';
$userId = requireLogin();

$pageTitle = 'Job seeker setup';
include __DIR__ . '/../includes/head.php';

// Pull from employment_types / industries tables in production instead of hardcoding.
$employmentTypes = ['Full-time', 'Part-time', 'Contract', 'Internship', 'Remote'];
$industries = ['Technology', 'Finance', 'Healthcare', 'Retail', 'Design', 'Education'];
?>
<div class="screen">
  <div class="topbar">
    <a href="/onboarding/choose-role.php" class="back" aria-label="Back">‹</a>
    <div class="step-label">Job seeker setup</div>
    <div style="width:22px"></div>
  </div>
  <div class="content">
    <h1 class="title">Build your profile</h1>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/onboarding/employee-setup-submit.php" enctype="multipart/form-data" class="stack">

      <div class="row">
        <div class="avatar-upload" aria-hidden="true">+</div>
        <label class="btn-small" for="picture">Upload photo</label>
        <input id="picture" name="picture" type="file" accept="image/*" style="display:none">
      </div>

      <div class="field">
        <label for="age">Age</label>
        <input id="age" name="age" type="number" min="16" max="100" placeholder="27" required>
      </div>
      <div class="field">
        <label for="location">Location</label>
        <input id="location" name="location" type="text" placeholder="Ahmedabad, India" required>
      </div>
      <div class="field">
        <label for="nationality">Nationality</label>
        <input id="nationality" name="nationality" type="text" placeholder="Indian">
      </div>
      <div class="field">
        <label for="qualification">Qualification</label>
        <input id="qualification" name="qualification" type="text" placeholder="B.Tech, Computer Science">
      </div>
      <div class="field">
        <label for="experience">Experience (years)</label>
        <input id="experience" name="experience" type="number" step="0.5" min="0" placeholder="3">
      </div>
      <div class="field">
        <label for="expected_salary">Expected salary</label>
        <input id="expected_salary" name="expected_salary" type="number" min="0" placeholder="e.g. 1200000">
      </div>

      <div>
        <div class="eyebrow" style="margin-bottom:10px">Employment type</div>
        <div class="chip-group" data-multi="false">
          <?php foreach ($employmentTypes as $i => $type): ?>
            <span class="chip<?= $i === 0 ? ' active' : '' ?>" data-value="<?= htmlspecialchars($type) ?>"><?= htmlspecialchars($type) ?></span>
          <?php endforeach; ?>
        </div>
        <input type="hidden" name="employment_type" id="employment_type" value="<?= htmlspecialchars($employmentTypes[0]) ?>">
      </div>

      <div>
        <div class="eyebrow" style="margin-bottom:10px">Industries</div>
        <div class="chip-group" data-multi="true">
          <?php foreach ($industries as $ind): ?>
            <span class="chip" data-value="<?= htmlspecialchars($ind) ?>"><?= htmlspecialchars($ind) ?></span>
          <?php endforeach; ?>
        </div>
        <input type="hidden" name="industries" id="industries" value="">
      </div>

      <div>
        <div class="eyebrow" style="margin-bottom:10px">Resume / CV</div>
        <label for="cv" class="dropzone" style="display:block;cursor:pointer">
          <div class="name">Upload your CV</div>
          <div class="hint">PDF, up to 10 MB</div>
        </label>
        <input id="cv" name="cv" type="file" accept=".pdf" style="display:none">
      </div>

      <button type="submit" class="btn btn-primary">Complete setup</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
