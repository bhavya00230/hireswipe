<?php
/**
 * onboarding/employer-setup-submit.php
 * Handles POST from onboarding/employer-setup.php.
 * Upserts employer_profiles, inserts the first jobs row, and marks
 * onboarding complete with role = employer.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$userId = requireLogin();

function backToEmployerSetup(string $error): void
{
    $_SESSION['flash_error'] = $error;
    header('Location: /onboarding/employer-setup.php');
    exit;
}

$companyName    = trim($_POST['company_name'] ?? '');
$location       = trim($_POST['location'] ?? '');
$industry       = trim($_POST['industry'] ?? '');
$position       = trim($_POST['position'] ?? '');
$employmentType = trim($_POST['employment_type'] ?? '');
$salary         = trim($_POST['salary'] ?? '');
$jobDetails     = trim($_POST['job_details'] ?? '');

if ($companyName === '' || $location === '' || $position === '' || $jobDetails === '') {
    backToEmployerSetup('Company name, location, position and job details are required.');
}

try {
    $logoPath = handleUpload($_FILES['logo'] ?? [], 'logos');
} catch (RuntimeException $e) {
    backToEmployerSetup($e->getMessage());
}

$industryId = $industry !== '' ? getOrCreateLookupId($pdo, 'industries', $industry) : null;
$employmentTypeId = $employmentType !== '' ? getOrCreateLookupId($pdo, 'employment_types', $employmentType) : null;

$pdo->beginTransaction();
try {
    // Upsert: one company profile row per user (employer_profiles.user_id is UNIQUE).
    $stmt = $pdo->prepare(
        'INSERT INTO employer_profiles (user_id, company_name, location, industry_id, logo_path)
         VALUES (:user_id, :company_name, :location, :industry_id, :logo_path)
         ON DUPLICATE KEY UPDATE
            company_name = VALUES(company_name),
            location = VALUES(location),
            industry_id = VALUES(industry_id),
            logo_path = COALESCE(VALUES(logo_path), logo_path)'
    );
    $stmt->execute([
        'user_id'      => $userId,
        'company_name' => $companyName,
        'location'     => $location,
        'industry_id'  => $industryId,
        'logo_path'    => $logoPath,
    ]);

    $employerId = (int) $pdo->query('SELECT id FROM employer_profiles WHERE user_id = ' . (int) $userId)->fetchColumn();

    // The onboarding form always creates a fresh job posting.
    $pdo->prepare(
        'INSERT INTO jobs (employer_id, position, employment_type_id, salary, job_details)
         VALUES (:employer_id, :position, :employment_type_id, :salary, :job_details)'
    )->execute([
        'employer_id'        => $employerId,
        'position'           => $position,
        'employment_type_id' => $employmentTypeId,
        'salary'             => $salary !== '' ? $salary : null,
        'job_details'        => $jobDetails,
    ]);

    $pdo->prepare("UPDATE users SET role = 'employer', onboarding_status = 'completed' WHERE id = :id")
        ->execute(['id' => $userId]);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    backToEmployerSetup('Something went wrong saving your company. Please try again.');
}

header('Location: /dashboard.php');
exit;
