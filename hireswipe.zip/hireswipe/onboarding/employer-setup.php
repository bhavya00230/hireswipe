<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';
$userId = requireLogin();

$pageTitle = 'Employer setup';
include __DIR__ . '/../includes/head.php';

$employmentTypes = ['Full-time', 'Part-time', 'Contract', 'Internship', 'Remote'];
?>
<div class="screen">
  <div class="topbar">
    <a href="/onboarding/choose-role.php" class="back" aria-label="Back">‹</a>
    <div class="step-label">Employer setup</div>
    <div style="width:22px"></div>
  </div>
  <div class="content">
    <h1 class="title">Set up your company</h1>

    <?php if (!empty($_SESSION['flash_error'])): ?>
      <p role="alert" style="margin:0;font-size:14px;color:var(--danger)"><?= htmlspecialchars($_SESSION['flash_error']) ?></p>
      <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>

    <form method="post" action="/onboarding/employer-setup-submit.php" enctype="multipart/form-data" class="stack">

      <div class="row">
        <div class="avatar-upload logo-upload" aria-hidden="true">+</div>
        <label class="btn-small" for="logo">Upload logo</label>
        <input id="logo" name="logo" type="file" accept="image/*" style="display:none">
      </div>

      <div class="field">
        <label for="company_name">Company name</label>
        <input id="company_name" name="company_name" type="text" placeholder="Acme Robotics" required>
      </div>
      <div class="field">
        <label for="location">Location</label>
        <input id="location" name="location" type="text" placeholder="Ahmedabad, India" required>
      </div>
      <div class="field">
        <label for="industry">Industry</label>
        <input id="industry" name="industry" type="text" placeholder="Technology">
      </div>

      <hr class="hr">
      <div class="eyebrow">First job posting</div>

      <div class="field">
        <label for="position">Position</label>
        <input id="position" name="position" type="text" placeholder="Senior Product Designer" required>
      </div>

      <div>
        <div class="eyebrow" style="margin-bottom:10px">Employment type</div>
        <div class="chip-group" data-multi="false">
          <?php foreach ($employmentTypes as $i => $type): ?>
            <span class="chip<?= $i === 0 ? ' active' : '' ?>" data-value="<?= htmlspecialchars($type) ?>"><?= htmlspecialchars($type) ?></span>
          <?php endforeach; ?>
        </div>
        <input type="hidden" name="employment_type" id="employment_type" value="<?= htmlspecialchars($employmentTypes[0]) ?>">
      </div>

      <div class="field">
        <label for="salary">Salary</label>
        <input id="salary" name="salary" type="number" min="0" placeholder="e.g. 1800000">
      </div>
      <div class="field">
        <label for="job_details">Job details</label>
        <textarea id="job_details" name="job_details" rows="5" placeholder="Role responsibilities, requirements and benefits..." required></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Complete setup</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
